// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"or4r":[function(require,module,exports) {
var global = arguments[3];
/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        result = wait - timeSinceLastCall;

    return maxing ? nativeMin(result, maxWait - timeSinceLastInvoke) : result;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = debounce;

},{}],"WEtf":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
// device sniffing for mobile
var isMobile = {
  android: function android() {
    return navigator.userAgent.match(/Android/i);
  },
  blackberry: function blackberry() {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  ios: function ios() {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  opera: function opera() {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  windows: function windows() {
    return navigator.userAgent.match(/IEMobile/i);
  },
  any: function any() {
    return isMobile.android() || isMobile.blackberry() || isMobile.ios() || isMobile.opera() || isMobile.windows();
  }
};
var _default = isMobile;
exports.default = _default;
},{}],"hZBy":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.select = select;
exports.selectAll = selectAll;
exports.find = find;
exports.removeClass = removeClass;
exports.addClass = addClass;
exports.hasClass = hasClass;
exports.jumpTo = jumpTo;

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

// DOM helper functions
// public
function select(selector) {
  return document.querySelector(selector);
}

function selectAll(selector) {
  var parent = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return _toConsumableArray(parent.querySelectorAll(selector));
}

function find(el, selector) {
  return _toConsumableArray(el.querySelectorAll(selector));
}

function removeClass(el, className) {
  if (el.classList) el.classList.remove(className);else el.className = el.className.replace(new RegExp("(^|\\b)".concat(className.split(' ').join('|'), "(\\b|$)"), 'gi'), ' ');
}

function addClass(el, className) {
  if (el.classList) el.classList.add(className);else el.className = "".concat(el.className, " ").concat(className);
}

function hasClass(el, className) {
  if (el.classList) return el.classList.contains(className);
  return new RegExp("(^| )".concat(className, "( |$)"), 'gi').test(el.className);
}

function jumpTo(el, offset) {
  offset = offset || 0;
  var top = el.getBoundingClientRect().top + offset;
  var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  var destY = scrollTop + top;
  window.scrollTo(0, destY);
}
},{}],"U9xJ":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = linkFix;

var _dom = require("./dom");

/**
 * Fixes target blanks links
 */
function linkFix() {
  var links = (0, _dom.selectAll)("[target='_blank']");
  links.forEach(function (link) {
    return link.setAttribute("rel", "noopener");
  });
}
},{"./dom":"hZBy"}],"b9Lb":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _default = [{
  quizID: 1,
  main: [4, 10],
  uncensored: null,
  exact: [2, 3, 4, 5, 8, 9, 10]
}, {
  quizID: 2,
  main: [3, 11],
  uncensored: null,
  exact: [3, 9, 10, 11]
}, {
  quizID: 3,
  main: null,
  uncensored: 9,
  exact: []
}, {
  quizID: 4,
  main: [6],
  uncensored: null,
  exact: [6, 7, 8]
}, {
  quizID: 5,
  main: [7],
  uncensored: 2,
  exact: [7]
}];
exports.default = _default;
},{}],"qa0R":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function prepare(sel) {
  if (!sel.size()) return false;
  var html = sel.html().split(' ' || '<br>').map(function (d, i) {
    return "<span data-index=".concat(i, ">").concat(d, "</span>");
  }).join(' ');
  sel.html(html);
  return true;
}

var _default = {
  prepare: prepare
};
exports.default = _default;
},{}],"xZJw":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = loadData;

/* global d3 */

/* usage
	import loadData from './load-data'
	
	loadData('file.csv').then(result => {
		console.log(result);
	}).catch(console.error);

	loadData(['file1.csv', 'file2.json]).then(result => {
		console.log(result);
	}).catch(console.error);
*/
function loadFile(file) {
  return new Promise(function (resolve, reject) {
    var ext = file.split('.').pop();
    if (ext === 'csv') d3.csv("assets/data/".concat(file)).then(resolve).catch(reject);else if (ext === 'json') d3.json("assets/data/".concat(file)).then(resolve).catch(reject);else reject(new Error("unsupported file type for: ".concat(file)));
  });
}

function loadData(files) {
  if (typeof files === 'string') return loadFile(files);
  var loads = files.map(loadFile);
  return Promise.all(loads);
}
},{}],"mJmG":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var wordData = [];
var groupData = [];
var $groupIN = d3.selectAll('#catIN');
var $groupCEN = d3.selectAll('#catCEN');
var $groupPCT = d3.selectAll('#catPCT');
var $wordIN = d3.selectAll('#wordIN');
var $wordCEN = d3.selectAll('#wordCEN');
var $wordPCT = d3.selectAll('#wordPCT');

function populateGroupText(category) {
  var filteredData = groupData.filter(function (d) {
    return d.category == category;
  });
  var groupINData = filteredData[0].inSongs;
  var groupCENData = filteredData[0].censored;
  var groupPCTData = filteredData[0].pctCensored;
  groupPCTData = Number(groupPCTData).toFixed(1);
  $groupIN.text("".concat(groupINData));
  $groupCEN.text("".concat(groupCENData));
  $groupPCT.text("".concat(groupPCTData));
}

function populateWordText(word) {
  var filteredData = wordData.filter(function (d) {
    return d.badword == word;
  });
  var wordINData = filteredData[0].inSongs;
  var wordCENData = filteredData[0].censored;
  var wordPCTData = filteredData[0].pctCensored;
  wordPCTData = Number(wordPCTData).toFixed(1);
  $wordIN.text("".concat(wordINData));
  $wordCEN.text("".concat(wordCENData));
  $wordPCT.text("".concat(wordPCTData));
}

function init() {
  (0, _loadData.default)(['groupOverviewNumbers.csv', 'wordOverviewNumbers.csv']).then(function (result) {
    groupData = result[0];
    wordData = result[1];
  }).catch(console.error);
}

var _default = {
  init: init,
  populateGroupText: populateGroupText,
  populateWordText: populateWordText
};
exports.default = _default;
},{"./load-data":"xZJw"}],"MBJX":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

var _percentages = _interopRequireDefault(require("./percentages"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var cwMap = null;
var data = [];
var filteredData = [];
var $dropdown = d3.select('.first-select');
var $compare = d3.select('#slide_18').select('.compare-wrapper');

function cleanLyrics(lyr) {
  var cleaned = lyr.map(function (d) {
    return _objectSpread({}, d, {
      category: cwMap.get(d.word)
    });
  });
  return cleaned;
}

function handleToggle() {
  var container = d3.select(this);
  var thisSwitch = container.select('input');
  var checked = thisSwitch.attr('checked');
  var toggleParent = d3.select(this.parentNode);
  var headParent = d3.select(toggleParent.node().parentNode);
  var lyricParent = d3.select(headParent.node().parentNode);
  var lyrics = lyricParent.select('.origLyric');
  var thisToggleKB = toggleParent.selectAll('.toggle-kb');
  var thisToggleOG = toggleParent.selectAll('.toggle-og'); // console.log({ parent, lyrics, lyricParent, checked });
  // console.log(toggleParent)

  if (checked === 'true') {
    lyrics.transition().duration(100).delay(0).ease(d3.easeLinear).text(function (d) {
      return d.original;
    });
    thisToggleKB.classed('toggle-on', false);
    thisToggleOG.classed('toggle-on', true);
  } else {
    lyrics.transition().duration(100).delay(0).ease(d3.easeLinear).text(function (d) {
      return d.kb;
    });
    thisToggleKB.classed('toggle-on', true);
    thisToggleOG.classed('toggle-on', false);
  } // console.log({ thisSwitch, checked });


  thisSwitch.attr('checked') === 'true' ? thisSwitch.attr('checked', 'false') : thisSwitch.attr('checked', 'true');
}

function handleDropdown(val) {
  // generate new lyric sets for each song
  var singleWord = filteredData.filter(function (d) {
    return d.key === val;
  })[0].values.sort(function (a, b) {
    return d3.descending(+a.kb_deets, +b.kb_deets);
  });
  $compare.selectAll('.lyric-set').data(singleWord, function (d) {
    return d ? d.word : null;
  }).join(function (enter) {
    var $set = enter.append('div').attr('class', 'lyric-set');
    var $head = $set.append('div').attr('class', 'lyric-head');
    $set.append('p').attr('class', 'origLyric').text(function (d) {
      return d.kb;
    });
    var $deets = $head.append('div').attr('class', 'deets');
    $deets.append('p').attr('class', 'song').text(function (d) {
      return d.song;
    });
    $deets.append('p').attr('class', 'kb-deets').text(function (d) {
      return "Kidz Bop (".concat(d.kb_deets, ")");
    });
    $deets.append('p').attr('class', 'orig-deets').text(function (d) {
      return d.original_deets;
    });
    var $toggle = $head.append('div').attr('class', 'toggle');
    $toggle.append('p').attr('class', 'toggle-labels toggle-kb toggle-on').text('KB');
    var $switch = $toggle.append('label').attr('class', 'switch');
    $switch.append('input').attr('type', 'checkbox').attr('class', 'is-kb').attr('checked', 'true');
    $switch.append('span').attr('class', 'slider round');
    $switch.on('change', handleToggle);
    $toggle.append('p').attr('class', 'toggle-labels toggle-og').text('OG');
  });
}

function updateDropdown() {
  var sortedData = filteredData.sort(function (a, b) {
    return d3.ascending(a.key, b.key);
  }); //console.log(filteredData)

  $dropdown.selectAll('option').data(filteredData, function (d) {
    return d.key;
  }).join(function (enter) {
    return enter.append('option').text(function (d) {
      return d.key;
    }).attr('value', function (d) {
      return d.key;
    });
  });
  $dropdown.on('change', function () {
    var val = d3.select(this).property('value');
    handleDropdown(val);

    _percentages.default.populateWordText(val);
  });
}

function filter(cat) {
  var filtered = data.filter(function (d) {
    return d.category === cat;
  });
  filteredData = d3.nest().key(function (d) {
    return d.word;
  }).rollup(function (leaves) {
    var length = leaves.length;
    return {
      length: length,
      values: leaves
    };
  }).entries(filtered).map(function (d) {
    return {
      key: d.key,
      length: d.value.length,
      values: d.value.values
    };
  });

  if (filteredData) {
    updateDropdown();
    var first = null;

    if (cat == 'alcohol') {
      first = filteredData[17].key;
      $dropdown.node().options[17].selected = true;
    } else if (cat == 'sexual') {
      first = filteredData[22].key;
      $dropdown.node().options[22].selected = true;
    } else if (cat == 'profanity') {
      first = filteredData[6].key;
      $dropdown.node().options[6].selected = true;
    } else if (cat == 'violence') {
      first = filteredData[11].key;
      $dropdown.node().options[11].selected = true;
    } else if (cat == 'identity') {
      first = filteredData[2].key;
      $dropdown.node().options[2].selected = true;
    } else if (cat == 'other') {
      first = filteredData[16].key;
      $dropdown.node().options[16].selected = true;
    } else {
      first = filteredData[0].key;
    } //const first = filteredData[0].key;


    handleDropdown(first);

    _percentages.default.populateWordText(first);
  }
}

function resize() {}

function init() {
  (0, _loadData.default)(['cat_crosswalk.csv', 'cat_lyrics.csv']).then(function (result) {
    var cw = result[0].map(function (d) {
      return [d.word, d.category];
    });
    cwMap = new Map(cw);
    data = cleanLyrics(result[1]);
  }).catch(console.error);
}

var _default = {
  init: init,
  resize: resize,
  filter: filter
};
exports.default = _default;
},{"./load-data":"xZJw","./percentages":"mJmG"}],"TAPd":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _lyrics = _interopRequireDefault(require("./lyrics"));

var _prepareSpan = _interopRequireDefault(require("./utils/prepare-span"));

var _categories = _interopRequireDefault(require("./categories"));

var _percentages = _interopRequireDefault(require("./percentages"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* global d3 */
function resize() {}

var $slides = d3.selectAll('.slide');
var $methodOpen = d3.select('#method-button');
var $methodClose = d3.select('#method svg');
var $touch = d3.select('#touch');
var $fwdTapDiv = $touch.selectAll('#right');
var $bckTapDiv = $touch.selectAll('#left');
var $skipTapDiv = $touch.selectAll('#skipper');
var $beginTapDiv = $touch.selectAll('#begin');
var $categoryBars = d3.selectAll('.category-bar');
var $songCircles = d3.selectAll('.song-circle');
var $quizSlidesAll = $slides.filter(function (d, i, n) {
  return d3.select(n[i]).attr('data-quiz');
});
var $answerSlidesAll = $slides.filter(function (d, i, n) {
  return d3.select(n[i]).attr('data-answer');
});
var $count = d3.selectAll('#count');
var $quizDetails = d3.select('.quiz-details');
var $catSection = d3.select('#categories');
var $feedbackSentences = d3.selectAll('.quiz-feedback p');
var $lyricSpans = null;
var $currSlide = null;
var $currSlideID = null;
var $prevSlide = null;
var $nextSlide = null;
var $quizSlide = null;

function spanSetup() {
  // select all quiz slides then select the p element in each slide
  $quizSlidesAll.nodes().forEach(function (d) {
    var wrapper = d3.select(d).select('.lyric-wrapper p'); // then convert them to spans

    _prepareSpan.default.prepare(wrapper);
  });
  $lyricSpans = d3.selectAll('.lyric-wrapper span');
}

function spanHintSetup() {
  var firstQuizSlide = d3.selectAll('#slide_3');
  var firstLyrics = firstQuizSlide.selectAll('.lyric-wrapper p');
  var firstSpan = firstLyrics.selectAll('span');
  firstSpan.attr('class', function (d, i) {
    return i ? null : 'hintSpan';
  });
}

function updateSlideLocation() {
  // sets the current slide to whichever is visible
  $currSlide = d3.select('.is-visible-slide'); // find the ID of the current slide

  $currSlideID = +$currSlide.attr('data-slide'); // is the user on an answer slide in the quiz section?

  var answerSlide = $currSlideID >= 3 && ($currSlideID + 1) % 2 !== 0; // select the previous slide
  // if currently on an answer slide, go back 2

  $prevSlide = $slides.filter(function (d, i, n) {
    return d3.select(n[i]).attr('data-slide') === "".concat($currSlideID - 1);
  }); // select the global next slide

  $nextSlide = $slides.filter(function (d, i, n) {
    return d3.select(n[i]).attr('data-slide') === "".concat($currSlideID + 1);
  }); // hide header

  if ($currSlideID == 1) {
    d3.select('header').classed('is-visible', true);
    d3.select('#right').classed('pulse', true);
  } else {
    d3.select('header').classed('is-visible', false);
    d3.select('#right').classed('pulse', false);
  } // hide/show category bars


  if ($currSlideID == 17) {
    $catSection.classed('is-visible', true).style('pointer-events', 'all');
    $categoryBars.classed('not-chosen', false).classed('cat-chosen', false).transition().duration(250).delay(function (d, i) {
      return i * 25;
    }).ease(d3.easeLinear).style('transform', 'translate(0, 0)');
  } else if ($currSlideID < 17) {
    $catSection.classed('is-visible', false);
  }

  if (answerSlide) {
    $quizSlide = $slides.filter(function (d, i, n) {
      return d3.select(n[i]).attr('data-slide') === "".concat($currSlideID - 1);
    });
  } // update buttons


  updateButtons();
}

function slideSetup() {
  // create data attribute for each slide based on its index
  $slides.attr('data-slide', function (d, i) {
    return i + 1;
  });
  updateSlideLocation();
}

function checkCensors(censoredIndeces) {
  // first, see if they censored everything on the previous slide
  var allWords = $quizSlide.selectAll('span');
  var allCensored = $quizSlide.selectAll('.censored');
  var currQuiz = $quizSlide.attr('data-quiz'); // filter our pre-defined answers based on the current quiz id

  var thisMatch = _lyrics.default.filter(function (d) {
    return d.quizID === +currQuiz;
  })[0]; // words the user didn't censor that should've been


  var missed = thisMatch.exact.filter(function (element) {
    return !censoredIndeces.includes(element);
  }); // words the user DID censor that didn't need to be

  var extraCensored = censoredIndeces.filter(function (element) {
    return !thisMatch.exact.includes(element);
  });
  var selectedAll = allWords.size() === allCensored.size();
  var thisCircle = $songCircles.filter(function (d, i, n) {
    return d3.select(n[i]).attr('data-quiz') === currQuiz;
  });
  var thisFeedbackSlide = d3.selectAll('.slide').filter(function (d, i, n) {
    return d3.select(n[i]).attr('data-answer') === currQuiz;
  });
  var thisFeedbackSent = thisFeedbackSlide.selectAll('.compare-wrapper .quiz-feedback p'); // were each of the main words censored?

  var mainWords = null;

  if (thisMatch.main) {
    mainWords = thisMatch.main.map(function (d) {
      return censoredIndeces.includes(d);
    });
  } else mainWords = ['true']; // add animations to feedback
  // Game Logic: if all words are censored, wrong and stop there
  // Else, see if they got an exact match, if so, Winner!
  // Else, see if at least main word is censored, if so, that's good, give it to them
  // Otherwise, loser


  if (selectedAll) {
    thisCircle.classed('is-wrong', true).classed('is-correct', false);
    thisFeedbackSent.classed('slide-in', true).classed('is-wrong', true).html("<span>Whoa!</span><br> You can't censor it all.");
  } else if (missed.length === 0 && extraCensored.length === 0) {
    // if they got an exact match, they win!
    thisCircle.classed('is-correct', true).classed('is-wrong', false);
    thisFeedbackSent.classed('slide-in', true).classed('is-correct', true).html("<span>Correct!</span><br> Do you secretly have a Kidz Bop playlist?");
  } else if (thisMatch.uncensored && censoredIndeces.includes(thisMatch.uncensored)) {
    // if they missed some words, but also censored one that you would expect to be censored (e.g., champagne)
    // but that wasn't censored in this instance, it's wrong.
    var wrongWord = d3.select(allWords.nodes()[thisMatch.uncensored]).text();
    wrongWord = wrongWord.replace(',', '');
    thisCircle.classed('is-wrong', true).classed('is-correct', false);
    thisFeedbackSent.classed('slide-in', true).classed('is-wrong', true).html("<span>Oops!</span><br> Kidz Bop didn't actually censor \"".concat(wrongWord, ".\""));
  } else if (missed.length > 0 && !mainWords.includes(false)) {
    // if they missed some words, but still got the main one, correct
    thisCircle.classed('is-correct', true).classed('is-wrong', false);
    thisFeedbackSent.classed('slide-in', true).classed('is-correct', true).html("<span>This counts!</span><br> You found the main censored word.");
  } else {
    thisCircle.classed('is-wrong', true).classed('is-correct', false);
    thisFeedbackSent.classed('slide-in', true).classed('is-wrong', true).html("<span>Yikes!</span><br> This still needs a parental advisory label.");
  }
}

function findCensored() {
  // select all censored spans
  var allCensored = $quizSlide.selectAll('.censored'); // create empty array for all censored span indeces

  var censoredIndeces = []; // for each span that is censored, collect the index and push it to censoredIndeces

  allCensored.each(function pushIndeces() {
    var word = d3.select(this);
    var index = word.attr('data-index');
    censoredIndeces.push(+index);
  });
  checkCensors(censoredIndeces);
}

function spanCensor() {
  // select the word that was clicked
  var word = d3.select(this); // remove prompt

  $lyricSpans.classed('hintSpan', false); // is this word already censored?

  var isCensored = word.classed('censored'); // if so, make it uncensored, if not, censor it

  word.classed('censored', !isCensored);
}

function buttonSetup() {
  d3.selectAll('#left').classed('is-visible', false);
  d3.selectAll('#right').classed('solo', true);
}

function findTotalCorrect() {
  var correct = $quizDetails.selectAll('.is-correct');
  var correctCount = correct.size();
  d3.select('.correct-count').text(correctCount);
  d3.select('.results-sentence').text(function () {
    if (correctCount <= 2) {
      return "Kids, earmuffs! Did you even really try?!";
    }

    if (correctCount < 4 && correctCount > 2) {
      return "This might seem safe for the radio, but not for Kidz Bop.";
    }

    return "The FCC has nothing on you!";
  });
}

function updateButtons() {
  var $prompt = d3.selectAll('#prompt');
  var $left = d3.selectAll('#left');
  var $right = d3.selectAll('#right');
  var $rightText = $right.select('button p'); // this will return true if a quiz or answer slide, and false if not

  var quizOrAnswer = $currSlide.attr('data-quiz') || $currSlide.attr('data-answer') || $currSlideID === 13;
  if ($currSlideID === 2) $rightText.text('Take the quiz'); // if current slide is quiz slide, make it read Submit
  else if ($currSlide.attr('data-quiz')) $rightText.text("I think I've got it"); // if current slide is answer slide (and isn't #12), make it read Next Song
    else if ($currSlide.attr('data-answer') && $currSlideID !== 12) $rightText.text('Next Song');else if ($currSlideID === 12) $rightText.text('Show my results');else if ($currSlideID === 13) $rightText.text('Tell me more');else if ($currSlideID === 1) $rightText.text("Let's find out"); // if on slide 2, this will evaluate to true, otherwise false

  $skipTapDiv.classed('is-visible', [2].includes($currSlideID));
  $beginTapDiv.classed('is-visible', [18].includes($currSlideID));
  d3.selectAll('.bottom-fade').classed('is-visible', [18].includes($currSlideID)); // toggling button visibility
  // if the current slide id is in the array, this should evaulate to true, otherwise false

  $left.classed('is-visible', [14, 15, 16, 18].includes($currSlideID));
  $right.classed('is-visible', ![17, 18].includes($currSlideID));
  $right.classed('solo', $currSlideID <= 13);
  $left.classed('solo', $currSlideID == 18); // show tapping prompt
  // $prompt.classed('is-visible', $currSlideID == 3)
  // if ($prompt.classed('is-visible')) {
  //   console.log('yup')
  //   //window.addEventListener('click', $prompt.classed('is-visible', false))
  // }
  // show quiz details on quiz and answer slides

  $quizDetails.classed('is-visible', quizOrAnswer); // update count if on quiz slides

  if ($currSlide.attr('data-quiz')) {
    $count.text($currSlide.attr('data-quiz'));
  } // if on slide 12, count number of correct attempts


  if ($currSlideID === 13) {
    findTotalCorrect();
    $quizDetails.classed('total', true);
  } // if above slide 16, remove pointer events for touch


  if ($currSlideID > 16 && $currSlideID < 18) {
    // console.log({ $touch });
    $touch.style('pointer-events', 'none');
  } else $touch.style('pointer-events', 'all');
}

function fwdTap() {
  // console.log({ $currSlide });
  // is the current slide a quiz slide?
  var $currQuiz = $currSlide.attr('data-quiz');
  $currSlide.classed('is-visible-slide', false);
  $nextSlide.classed('is-visible-slide', true); // update current, previous, and next

  updateSlideLocation(); // if the current slide is a quiz slide, evaluate answer on tap

  if ($currQuiz) {
    findCensored();
  }
}

function methodOpen() {
  d3.select('#method').classed('is-visible', true);
  d3.selectAll('body').style('overflow', 'scroll');
}

function methodClose() {
  d3.select('#method').classed('is-visible', false);
  d3.selectAll('body').style('overflow', 'hidden');
}

function bckTap() {
  $currSlide.classed('is-visible-slide', false);
  $prevSlide.classed('is-visible-slide', true); // update current, previous, and next

  updateSlideLocation();
}

function skipTap() {
  // temporarily make all slides invisible
  $slides.classed('is-visible-slide', false); // select the first post-quiz slide and make it visible

  d3.select('[data-chart="bar"]').classed('is-visible-slide', true); // reset the current, previous, & next slides globally

  updateSlideLocation();
}

function beginTap() {
  // temporarily make all slides invisible
  $slides.classed('is-visible-slide', false); // select the first post-quiz slide and make it visible

  d3.select('#slide_1').classed('is-visible-slide', true); // reset the current, previous, & next slides globally

  updateSlideLocation(); // resets quiz counting

  d3.selectAll('.censored').classed('censored', false);
  d3.selectAll('.song-circle').classed('is-wrong', false);
  d3.selectAll('.song-circle').classed('is-correct', false);
  d3.selectAll('.quiz-details').classed('total', false);
}

function handleCatBack(arrow) {
  var btnText = arrow.select('p');
  var direction = arrow.attr('data-direction');
  btnText.classed('is-visible', false);
  arrow.select('button').transition().duration(25).delay(100).ease(d3.easeLinear).style('transform', "rotate(0deg)");
  $categoryBars.classed('not-chosen', false).classed('cat-chosen', false).transition().duration(250).delay(function (d, i) {
    return i * 25;
  }).ease(d3.easeLinear).style('transform', 'translate(0, 0)'); // prevent catTap() from also being called

  if (direction === 'back') d3.event.stopPropagation(); // arrow.attr('data-direction', 'forward');
  // trigger a tap back one slide

  bckTap(); // adds pointer events back to section

  $catSection.style('pointer-events', 'all');
}

function setupArrowButton() {
  // const allArrows = $categoryBars.selectAll('.button-wrapper');
  var allArrows = $categoryBars;
  allArrows.on('click', function () {
    var bar = d3.select(this);
    var dir = bar.attr('data-cat');
    if (dir === 'back') handleCatBack(bar);else {
      catTap(bar);
    } // update direction
    //button.attr('data-direction', dir === 'back' ? 'forward' : 'back');
  });
}

function catTap(block) {
  // console.log(block)
  var clickedCat = block.node().attr;
  var currCat = block.classed('cat-chosen', true);
  currCat.classed('not-chosen', false);
  var currBckText = currCat.select('.button-wrapper p');
  var currBckButton = currCat.select('.button-wrapper button');
  var notCat = d3.selectAll('.category-bar').filter(function () {
    return !this.classList.contains('cat-chosen');
  }); // console.log(notCat)

  var currPos = block.node().getBoundingClientRect(); // console.log({ currCat, notCat, block });

  notCat.transition().duration(250).delay(function (d, i) {
    return i * 25;
  }).ease(d3.easeLinear).style('transform', 'translate(-100%)');
  currCat.transition().duration(250).delay(250).ease(d3.easeLinear).style('transform', 'translate(100%)'); // .style('transform', `translate(0, -${currPos.top -70}px)`);
  // replace category span on dropdown page

  var categoryAttr = currCat.node().getAttribute('data-cat');
  var categorySpan = d3.selectAll('#category-sent');
  categorySpan.text(function () {
    if (categoryAttr == 'alcohol') {
      return 'alcohol & drugs';
    } else if (categoryAttr == 'sexual') {
      return 'sexual references';
    }

    return categoryAttr;
  });
  categorySpan.attr('class', null);
  categorySpan.classed("".concat(categoryAttr, "-sent"), true); // trigger a tap forward one slide

  fwdTap(); // trigger a data update

  _categories.default.filter(currCat.attr('data-cat')); // trigger the text to update


  var groupTextCat = categorySpan.text();

  _percentages.default.populateGroupText(groupTextCat); // removes pointer events to allow for clicking on slide


  $catSection.style('pointer-events', 'none');
  currBckButton.style('pointer-events', 'all');
}

function init() {
  slideSetup();
  spanSetup();
  buttonSetup();
  setupArrowButton();
  spanHintSetup();
  $methodOpen.on('click', methodOpen);
  $methodClose.on('click', methodClose);
  d3.select('#method').on('click', methodClose);
  $fwdTapDiv.on('click', fwdTap);
  $bckTapDiv.on('click', bckTap);
  $skipTapDiv.on('click', skipTap);
  $beginTapDiv.on('click', beginTap);
  $lyricSpans.on('click', spanCensor);
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{"./lyrics":"b9Lb","./utils/prepare-span":"qa0R","./categories":"MBJX","./percentages":"mJmG"}],"lhDN":[function(require,module,exports) {
/* global d3 */

/*
 USAGE (example: line chart)
 1. c+p this template to a new file (line.js)
 2. change puddingChartName to puddingChartLine
 3. in graphic file: import './pudding-chart/line'
 4a. const charts = d3.selectAll('.thing').data(data).puddingChartLine();
 4b. const chart = d3.select('.thing').datum(datum).puddingChartLine();
*/
d3.selection.prototype.stackedBar = function init(options) {
  function createChart(el) {
    // dom elements
    var $chart = d3.select(el);
    var $svg = null;
    var $axis = null;
    var $vis = null; // data

    var _data = $chart.datum(); // dimensions


    var width = 0;
    var height = 0;
    var MARGIN_TOP = 0;
    var MARGIN_BOTTOM = 0;
    var MARGIN_LEFT = 50;
    var MARGIN_RIGHT = 0; // scales

    var scaleX = d3.scaleLinear();
    var scaleY = null; // helper functions

    var Chart = {
      // called once at start
      init: function init() {
        // add parent div for each year row
        $chart.selectAll('.year').data(_data, function (d) {
          return d.year;
        }).join(function (enter) {
          var year = enter.append('div').attr('class', 'year'); // add a p element for the year

          year.append('p').attr('class', 'year__number').text(function (d) {
            return d.year;
          }); // and another div to contain the bars

          var container = year.append('div').attr('class', 'year__barCont');
          return year;
        });
        $chart;
      },
      // on resize, update new dimensions
      resize: function resize() {
        // defaults to grabbing dimensions from container element
        width = $chart.node().offsetWidth - MARGIN_LEFT - MARGIN_RIGHT;
        height = $chart.node().offsetHeight - MARGIN_TOP - MARGIN_BOTTOM;
        var max = d3.max(_data, function (d) {
          return d.total;
        });
        scaleX.domain([0, max]).range([0, width]);
        return Chart;
      },
      // update scales and render chart
      render: function render() {
        var $barCont = $chart.selectAll('.year__barCont');
        var bar = $barCont.selectAll('.bar').data(function (d) {
          return d.censored;
        }).join(function (enter) {
          return enter.append('div').attr('class', function (d) {
            return "bar bar--".concat(d.key);
          });
        });
        bar.style('width', function (d) {
          return "".concat(scaleX(d.value), "px");
        }).style('height', '10px');
        return Chart;
      },
      // get / set data
      data: function data(val) {
        if (!arguments.length) return _data;
        _data = val;
        $chart.datum(_data);
        return Chart;
      }
    };
    Chart.init();
    return Chart;
  } // create charts


  var charts = this.nodes().map(createChart);
  return charts.length > 1 ? charts : charts.pop();
};
},{}],"JciQ":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

require("./pudding-chart/proportion-chart");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// selections
var $slides = d3.selectAll('[data-chart="bar"]');
var $containers = $slides.selectAll('.chart');
var charts = [];
var data = [];

function findTotal(d) {
  var censored = d.censored;
  var ent = censored.map(function (e) {
    return e.value;
  });
  var sum = d3.sum(ent);
  return sum;
}

function cleanData(data) {
  var cleaned = data.map(function (d) {
    return {
      year: +d.year,
      censored: d3.entries({
        alcohol: +d.alcohol,
        sexual: +d.sexual,
        profanity: +d.profanity,
        violence: +d.violence,
        identity: +d.identity,
        other: +d.other
      })
    };
  }).map(function (d) {
    return _objectSpread({}, d, {
      total: findTotal(d)
    });
  });
  return cleaned;
}

function resize() {
  charts.forEach(function (chart) {
    return chart.resize().render();
  });
}

function setupCharts() {
  var $sel = d3.select(this);
  var chart = $sel.data([data]).stackedBar();
  chart.resize().render();
  charts.push(chart);
}

function init() {
  (0, _loadData.default)('proportions-kb.csv').then(function (result) {
    data = cleanData(result);
    $containers.each(setupCharts);
  }).catch(console.error);
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{"./load-data":"xZJw","./pudding-chart/proportion-chart":"lhDN"}],"epB2":[function(require,module,exports) {
"use strict";

var _lodash = _interopRequireDefault(require("lodash.debounce"));

var _isMobile = _interopRequireDefault(require("./utils/is-mobile"));

var _linkFix = _interopRequireDefault(require("./utils/link-fix"));

var _graphic = _interopRequireDefault(require("./graphic"));

var _proportion = _interopRequireDefault(require("./proportion"));

var _categories = _interopRequireDefault(require("./categories"));

var _percentages = _interopRequireDefault(require("./percentages"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* global d3 */
// import footer from "./footer";
var $body = d3.select('body');
var previousWidth = 0;

function setVH() {
  var h = window.innerHeight + 'px';
  d3.select('#content').style('height', "".concat(h));
}

function resize() {
  // only do resize on width changes, not height
  // (remove the conditional if you want to trigger on height change)
  var width = $body.node().offsetWidth;

  if (previousWidth !== width) {
    previousWidth = width;

    _graphic.default.resize();

    _proportion.default.resize();

    setVH();
  }
}

function setupStickyHeader() {
  var $header = $body.select("header");

  if ($header.classed("is-sticky")) {
    var $menu = $body.select(".header__menu");
    var $toggle = $body.select(".header__toggle");
    $toggle.on("click", function () {
      var visible = $menu.classed("is-visible");
      $menu.classed("is-visible", !visible);
      $toggle.classed("is-visible", !visible);
    });
  }
}

function init() {
  // adds rel="noopener" to all target="_blank" links
  (0, _linkFix.default)();
  setVH(); // add mobile class to body tag

  $body.classed('is-mobile', _isMobile.default.any()); // setup resize event

  window.addEventListener('resize', (0, _lodash.default)(resize, 150)); // setup sticky header menu

  setupStickyHeader(); // kick off graphic code

  _graphic.default.init();

  _proportion.default.init();

  _categories.default.init();

  _percentages.default.init(); // load footer stories
  // footer.init();

}

init();
},{"lodash.debounce":"or4r","./utils/is-mobile":"WEtf","./utils/link-fix":"U9xJ","./graphic":"TAPd","./proportion":"JciQ","./categories":"MBJX","./percentages":"mJmG"}]},{},["epB2"], null)
//# sourceMappingURL=/main.js.map